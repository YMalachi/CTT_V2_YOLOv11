# CTT_V2_YOLOv8 > 2025-05-18 5:45pm
https://universe.roboflow.com/yotams-workspace/ctt_v2_yolov8

Provided by a Roboflow user
License: CC BY 4.0

